﻿namespace WebZootecPro.ViewModels.Eventos
{
    public enum TipoEventoReproductivo
    {
        Parto,
        Aborto,
        Servicio,
        Celo,
        Secado,
        Venta,
        Muerte,
        TactoRectal,
        Enfermedad,
        Medicacion,
        Rechazo,
        Analisis,
        IndicacionEspecial
    }
}
